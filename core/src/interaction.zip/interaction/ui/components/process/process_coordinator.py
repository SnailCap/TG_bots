from __future__ import annotations

from dataclasses import dataclass
from typing import List, Type, cast

from core.src.interaction.contracts.ui_builder import UiBuilder
from core.src.interaction.input.user_input import UserInput
from core.src.interaction.ui.binding import get_default_registry
from core.src.interaction.ui.components.process import Process
from core.src.interaction.ui.components.process.effects import (
    ProcessEffect,
    RenderStep,
    FinishProcess,
    CancelProcess,
)


class UnknownProcessKey(RuntimeError):
    pass


@dataclass(slots=True)
class ProcessCoordinator:
    ui: UiBuilder

    async def handle(self, user_input: UserInput) -> None:
        proc_key = user_input.state.get_active_process()
        if not proc_key:
            return

        proc = self._resolve_process(proc_key)

        # 1) дать текущему шагу обработать input
        idx = user_input.state.get_step_index(proc_key, 0)
        if idx < 0 or idx >= len(proc.step_names):
            raise IndexError(f"Step index out of range: {idx} for process '{proc_key}'")

        step_name = proc.step_names[idx]
        step = self.ui.build_step(step_name)
        await step.handle_input(user_input)

        # 2) процесс решает, что делать дальше
        effects = await proc.handle_input(user_input)

        # 3) применяем эффекты
        await self._apply_effects(user_input, effects)

    def _resolve_process(self, key: str) -> Process:
        registry = get_default_registry()
        cls = registry.get("process", key)

        if cls is None:
            raise UnknownProcessKey(f"Unknown process key: '{key}'")

        proc_cls = cast(Type[Process], cls)
        return proc_cls()

    async def _apply_effects(self, user_input: UserInput, effects: List[ProcessEffect]) -> None:
        for eff in effects:
            if isinstance(eff, RenderStep):
                step = self.ui.build_step(eff.step_name)
                await step.render(user_input, with_send=eff.with_send)
                continue

            if isinstance(eff, (FinishProcess, CancelProcess)):
                continue

    async def apply_effects(self, user_input: UserInput, effects: list[ProcessEffect]) -> None:
        await self._apply_effects(user_input, effects)