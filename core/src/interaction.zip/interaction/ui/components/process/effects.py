from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional, Union


@dataclass(frozen=True, slots=True)
class RenderStep:
    step_name: str
    with_send: bool = False


@dataclass(frozen=True, slots=True)
class FinishProcess:
    name: str


@dataclass(frozen=True, slots=True)
class CancelProcess:
    name: str


ProcessEffect = Union[RenderStep, FinishProcess, CancelProcess]