# user_input.py
from __future__ import annotations

from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession
from telegram import Update
from telegram.ext import ContextTypes

from core.src.interaction.contracts.messenger import Messenger
from core.src.interaction.state import InteractionState
from core.src.interaction.types import ServiceCallbackData
from core.src.interaction.types.user_input_type import UserInputType
from core.src.interaction.types.user_role import UserRole


def _svc_value(x) -> str:
    """
    Normalize enum-like values:
    - if x has .value -> return it
    - else assume it's already a string
    """
    return getattr(x, "value", x)


class UserInput:
    """
    Facade over Telegram Update + PTB Context + DB session + InteractionState.

    LoD goals:
    - Keep update/context/session available (to avoid breaking callers),
      but steer callers to use snapshot fields + helper properties/methods.
    - Centralize parsing of callback_data into intent-level flags.
    """

    def __init__(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        session: AsyncSession,
        *,
        messenger: Messenger,
        state: InteractionState,
    ):
        # Keep the original public API via properties (do not break external code).
        self._update = update
        self._context = context
        self._session: AsyncSession = session
        self._messenger = messenger
        self._state: InteractionState = state

        # identity snapshot (safe)
        user = update.effective_user
        chat = update.effective_chat
        msg = update.effective_message

        self.telegram_id: int = user.id if user else 0
        self.username: Optional[str] = user.username if user else None
        self.first_name: Optional[str] = user.first_name if user else None
        self.last_name: Optional[str] = user.last_name if user else None

        self.chat_id: int = chat.id if chat else 0
        self.message_id: int = msg.message_id if msg else 0

        self.user_role: UserRole = UserRole.PUBLIC

        # input (parsed snapshot)
        self.type: UserInputType = UserInputType.UNKNOWN
        self.text: Optional[str] = None
        self.callback_data: Optional[str] = None

        self._parse_input_from_update()

    # -------------------------
    # Backwards-compatible public access (but behind properties)
    # -------------------------

    @property
    def update(self) -> Update:
        return self._update

    @property
    def context(self) -> ContextTypes.DEFAULT_TYPE:
        return self._context

    @property
    def session(self) -> AsyncSession:
        return self._session

    @property
    def messenger(self) -> Messenger:
        return self._messenger

    @property
    def state(self) -> InteractionState:
        return self._state

    # -------------------------
    # Parsing (private)
    # -------------------------

    def _parse_input_from_update(self) -> None:
        """
        Parse input kind and payload safely.

        Notes:
        - For CALLBACK: callback_data is always a string (possibly empty).
        - For MESSAGE/COMMAND: text is stored (command without leading '/').
        - For unsupported updates: type stays UNKNOWN.
        """
        if self._update.callback_query is not None:
            self._parse_callback()
            return

        # Use update.message (not effective_message) because effective_message can be a callback message, etc.
        if self._update.message is not None:
            self._parse_message(self._update.message.text)
            return

        self.type = UserInputType.UNKNOWN
        self.text = None
        self.callback_data = None

    def _parse_callback(self) -> None:
        self.type = UserInputType.CALLBACK
        # callback_query.data can be None
        self.callback_data = self._update.callback_query.data or ""
        self.text = None

    def _parse_message(self, raw_text: Optional[str]) -> None:
        # raw_text can be None (e.g., sticker/photo)
        if not raw_text:
            self.type = UserInputType.MESSAGE
            self.text = None
            self.callback_data = None
            return

        if raw_text.startswith("/"):
            self.type = UserInputType.COMMAND
            # Keep only the command name without leading "/"
            self.text = raw_text[1:]
            self.callback_data = None
            return

        self.type = UserInputType.MESSAGE
        self.text = raw_text
        self.callback_data = None

    # -------------------------
    # Kind flags
    # -------------------------

    @property
    def is_command(self) -> bool:
        return self.type == UserInputType.COMMAND

    @property
    def is_callback(self) -> bool:
        return self.type == UserInputType.CALLBACK

    @property
    def is_message(self) -> bool:
        return self.type == UserInputType.MESSAGE

    # -------------------------
    # Convenience values
    # -------------------------

    @property
    def callback(self) -> str:
        """Callback data as non-null string."""
        return self.callback_data or ""

    @property
    def command(self) -> Optional[str]:
        """Command name (without '/') if this input is a command, else None."""
        return self.text if self.is_command else None

    @property
    def with_send_default(self) -> bool:
        """
        Default render strategy:
        - CALLBACK -> edit a bot message
        - MESSAGE/COMMAND -> send a new bot message
        """
        return not self.is_callback

    # -------------------------
    # Service callback parsing (intent-level)
    # -------------------------

    @property
    def is_service_callback(self) -> bool:
        return self.is_callback and self.callback.startswith(_svc_value(ServiceCallbackData.SVC))

    @property
    def is_nav_callback(self) -> bool:
        return self.is_service_callback and self.callback.startswith(_svc_value(ServiceCallbackData.NAV))

    @property
    def is_nav_previous(self) -> bool:
        return self.callback == _svc_value(ServiceCallbackData.NAV_PREVIOUS)

    @property
    def is_nav_current(self) -> bool:
        return self.callback == _svc_value(ServiceCallbackData.NAV_CURRENT)

    @property
    def is_nav_home(self) -> bool:
        return self.callback == _svc_value(ServiceCallbackData.NAV_HOME)

    @property
    def is_nav_to(self) -> bool:
        nav_to = getattr(ServiceCallbackData, "NAV_TO", None)
        return bool(nav_to) and self.callback.startswith(_svc_value(nav_to))

    @property
    def nav_target(self) -> Optional[str]:
        if not self.is_nav_to:
            return None
        target = self.callback.removeprefix(_svc_value(ServiceCallbackData.NAV_TO)).strip()
        return target or None

    # --- process start ---

    @property
    def is_proc_start(self) -> bool:
        return self.is_service_callback and self.callback.startswith(_svc_value(ServiceCallbackData.PRC_START))

    @property
    def proc_key(self) -> Optional[str]:
        if not self.is_proc_start:
            return None
        key = self.callback.removeprefix(_svc_value(ServiceCallbackData.PRC_START)).strip()
        return key or None

    # --- process commands ---

    @property
    def is_proc_cmd(self) -> bool:
        return self.is_service_callback and self.callback.startswith(_svc_value(ServiceCallbackData.PRC_CMD))

    @property
    def proc_cmd(self) -> Optional[str]:
        """
        Extract command after the PRC_CMD prefix.
        Examples:
          callback: "svc:prc:cmd next" -> "next"
          callback: "svc:prc:cmd:next" -> ":next" (depends on your format)
        We keep it flexible: strip whitespace, return raw tail.
        """
        if not self.is_proc_cmd:
            return None
        tail = self.callback.removeprefix(_svc_value(ServiceCallbackData.PRC_CMD)).strip()
        return tail or None

    @property
    def is_proc_next(self) -> bool:
        """
        True if the user requested "next step" via process command.
        Supports both:
          - explicit PRC_NEXT constant
          - proc_cmd tail containing "next"
        """
        prc_next = getattr(ServiceCallbackData, "PRC_NEXT", None)
        if prc_next and self.callback == _svc_value(prc_next):
            return True

        cmd = (self.proc_cmd or "").strip().lower()
        return cmd in {"next", "n", "forward", ">"}

    @property
    def is_proc_prev(self) -> bool:
        """
        True if a user requested "previous step" via process command.
        Supports both:
          - explicit PRC_PREV constant
          - proc_cmd tail containing "prev"
        """
        prc_prev = getattr(ServiceCallbackData, "PRC_PREV", None)
        if prc_prev and self.callback == _svc_value(prc_prev):
            return True

        cmd = (self.proc_cmd or "").strip().lower()
        return cmd in {"prev", "previous", "back", "<", "p"}

    # -------------------------
    # Messaging
    # -------------------------

    async def reply(self, text: str, reply_markup=None, with_send: bool = False):
        """
        Reply facade:
        - with_send=True -> always sends a new message
        - with_send=False -> send_or_edit using current message_id
        """
        if with_send:
            return await self._messenger.send(chat_id=self.chat_id, text=text, reply_markup=reply_markup)

        return await self._messenger.send_or_edit(
            chat_id=self.chat_id,
            message_id=self.message_id,
            text=text,
            reply_markup=reply_markup,
        )