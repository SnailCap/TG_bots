from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from core.src.interaction.contracts.state_store import StateStore
from core.src.interaction.types.user_data_key import UserDataPageKey, UserDataProcessKey


class InteractionState:
    """
    Facade over persistent StateStore + per-update ephemeral metadata.

    - Persistent: stored in StateStore (typically PTB user_data).
    - Ephemeral: stored in self._meta and should live for a single update.
    """

    # ---- internal constants to avoid magic strings ----
    _PROC_META: str = "meta"
    _PROC_PAYLOAD: str = "payload"
    _PROC_STEP_INDEX: str = "step_index"

    def __init__(self, store: StateStore) -> None:
        self._store = store
        self._meta: dict[str, Any] = {}  # ephemeral per-update metadata

    # ====== internal helpers ======

    @staticmethod
    def _norm_key(key: Any) -> str:
        """Normalize keys: Enum -> Enum.value -> str."""
        if isinstance(key, Enum):
            return str(key.value)
        return str(key)

    # ====== metadata (ephemeral) ======

    def set_meta(self, key: Any, value: Any) -> None:
        self._meta[self._norm_key(key)] = value

    def get_meta(self, key: Any, default: Any = None) -> Any:
        return self._meta.get(self._norm_key(key), default)

    def pop_meta(self, key: Any, default: Any = None) -> Any:
        return self._meta.pop(self._norm_key(key), default)

    # ====== low-level store passthrough ======

    def set(self, key: Any, value: Any) -> None:
        self._store.set(key, value)

    def get(self, key: Any, default: Any = None) -> Any:
        return self._store.get(key, default)

    def pop(self, key: Any, default: Any = None) -> Any:
        return self._store.pop(key, default)

    def has(self, key: Any) -> bool:
        return self._store.has(key)

    def dump(self) -> dict:
        return self._store.dump()

    # ====== process state (persistent) ======

    def _get_processes_root(self) -> dict:
        root = self.get(UserDataProcessKey.PROCESSES)
        if not isinstance(root, dict):
            root = {}
            self.set(UserDataProcessKey.PROCESSES, root)
        return root

    def _ensure_process_slot_shape(self, slot: dict) -> dict:
        """
        Ensure slot has required dict structure:
        {
          "meta": {"step_index": int},
          "payload": dict
        }
        """
        meta = slot.get(self._PROC_META)
        if not isinstance(meta, dict):
            meta = {}
            slot[self._PROC_META] = meta

        # step_index should be int-ish; if broken, reset to 0
        step_index = meta.get(self._PROC_STEP_INDEX, 0)
        try:
            meta[self._PROC_STEP_INDEX] = int(step_index)
        except (TypeError, ValueError):
            meta[self._PROC_STEP_INDEX] = 0

        payload = slot.get(self._PROC_PAYLOAD)
        if not isinstance(payload, dict):
            payload = {}
            slot[self._PROC_PAYLOAD] = payload

        return slot

    def _get_or_create_process_slot(self, process_name: str) -> dict:
        procs = self._get_processes_root()
        slot = procs.get(process_name)

        if not isinstance(slot, dict):
            slot = {self._PROC_META: {self._PROC_STEP_INDEX: 0}, self._PROC_PAYLOAD: {}}
            procs[process_name] = slot
            self.set(UserDataProcessKey.PROCESSES, procs)

        slot = self._ensure_process_slot_shape(slot)

        # re-store for safety if slot was malformed and fixed
        procs[process_name] = slot
        self.set(UserDataProcessKey.PROCESSES, procs)
        return slot

    def set_active_process(self, name: str) -> None:
        self.set(UserDataProcessKey.CURRENT_PROCESS, name)
        self._get_or_create_process_slot(name)

    def clear_active_process(self) -> None:
        self.pop(UserDataProcessKey.CURRENT_PROCESS)

    def has_active_process(self) -> bool:
        return self.has(UserDataProcessKey.CURRENT_PROCESS)

    def get_active_process(self) -> str:
        name = self.get(UserDataProcessKey.CURRENT_PROCESS)
        if not name:
            raise RuntimeError("No active process is set")
        name_str = str(name)

        # Ensure slot exists & is well-formed (helps with corrupted/legacy store)
        self._get_or_create_process_slot(name_str)
        return name_str

    def get_process_payload(self, process_name: str) -> dict:
        return self._get_or_create_process_slot(process_name)[self._PROC_PAYLOAD]

    def update_process_payload(self, process_name: str, **kwargs) -> None:
        slot = self._get_or_create_process_slot(process_name)
        slot[self._PROC_PAYLOAD].update(kwargs)

        procs = self._get_processes_root()
        procs[process_name] = slot
        self.set(UserDataProcessKey.PROCESSES, procs)

    def get_step_index(self, process_name: str, default: int = 0) -> int:
        slot = self._get_or_create_process_slot(process_name)
        value = slot[self._PROC_META].get(self._PROC_STEP_INDEX, default)
        try:
            return int(value)
        except (TypeError, ValueError):
            return int(default)

    def set_step_index(self, process_name: str, index: int) -> None:
        slot = self._get_or_create_process_slot(process_name)
        slot[self._PROC_META][self._PROC_STEP_INDEX] = int(index)

        procs = self._get_processes_root()
        procs[process_name] = slot
        self.set(UserDataProcessKey.PROCESSES, procs)

    def clear_process_state(self, process_name: str) -> None:
        procs = self._get_processes_root()
        if process_name in procs:
            procs.pop(process_name, None)
            self.set(UserDataProcessKey.PROCESSES, procs)

    # ====== step flow flags (ephemeral) ======

    def request_next_step(self) -> None:
        self.set_meta(UserDataProcessKey.NEXT_STEP_REQUESTED, True)

    def consume_next_step_request(self) -> bool:
        return bool(self.pop_meta(UserDataProcessKey.NEXT_STEP_REQUESTED, False))

    def set_finished_process(self, process_name: str) -> None:
        self.set_meta(UserDataProcessKey.FINISHED_PROCESS, process_name)

    def set_canceled_process(self, process_name: str) -> None:
        self.set_meta(UserDataProcessKey.CANCELED_PROCESS, process_name)

    def get_finished_process(self) -> Optional[str]:
        value = self.get_meta(UserDataProcessKey.FINISHED_PROCESS)
        return str(value) if value is not None else None

    def cancel_current_process(self) -> None:
        if not self.has_active_process():
            return

        name = self.get_active_process()
        self.clear_process_state(name)
        self.set_canceled_process(name)
        self.clear_active_process()

        # Clean ephemeral flags that could affect coordinator logic
        self.pop_meta(UserDataProcessKey.NEXT_STEP_REQUESTED, False)
        self.pop_meta(UserDataProcessKey.FINISHED_PROCESS, None)

    # ====== page state (persistent) ======

    def get_current_page(self) -> Optional[str]:
        value = self.get(UserDataPageKey.CURRENT_PAGE)
        return str(value) if value is not None else None

    def set_current_page(self, name: str) -> None:
        self.set(UserDataPageKey.CURRENT_PAGE, name)

    def reset_current_page(self) -> None:
        self.pop(UserDataPageKey.CURRENT_PAGE)

    def get_page_history(self) -> list[str]:
        history = self.get(UserDataPageKey.PAGE_HISTORY, [])
        if not isinstance(history, list):
            return []
        return [str(x) for x in history if x is not None]

    def set_page_history(self, history: list[str]) -> None:
        self.set(UserDataPageKey.PAGE_HISTORY, history)

    def push_page_to_history(self, page_name: str) -> None:
        name = self._norm_key(page_name)
        history = self.get_page_history()
        if not history or history[-1] != name:
            history.append(name)
            self.set_page_history(history)

    def get_previous_page(self) -> Optional[str]:
        history = self.get_page_history()
        return history[-2] if len(history) >= 2 else None

    def pop_last_page(self) -> Optional[str]:
        history = self.get_page_history()
        if not history:
            return None
        last = history.pop()
        self.set_page_history(history)
        return last