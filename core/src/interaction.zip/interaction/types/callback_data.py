from enum import Enum

class ServiceCallbackData(str, Enum):
    SVC = "svc:"

    NAV = "svc:nav:"
    NAV_TO = "svc:nav:to:"
    PRC_START = "svc:prc:start:"
    PRC_CMD = "svc:prc:cmd:"

    # nav targets
    NAV_PREVIOUS = "svc:nav:previous"
    NAV_CURRENT = "svc:nav:current"
    NAV_HOME = "svc:nav:home"

    # process commands
    PRC_NEXT = "svc:prc:cmd:next"
    PRC_PREV = "svc:prc:cmd:prev"
    PRC_CANCEL = "svc:prc:cmd:cancel"