from __future__ import annotations

from enum import Enum


class ProcessCommand(str, Enum):
    NEXT = "next"
    PREV = "prev"
    CANCEL = "cancel"